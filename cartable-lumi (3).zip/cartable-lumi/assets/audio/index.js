// Liste des voix enregistrées. Vide tant que « npm run voix » n'a pas été lancé.
window.AUDIO_INDEX=window.AUDIO_INDEX||{};
